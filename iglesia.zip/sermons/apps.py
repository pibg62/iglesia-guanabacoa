from django.apps import AppConfig


class SermonsConfig(AppConfig):
    name = 'sermons'
